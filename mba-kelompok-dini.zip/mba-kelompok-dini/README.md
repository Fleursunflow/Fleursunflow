# Market Basket Analysis using Streamlit

In this project we did Market Basket Analysis on a grocery shopping data using Apriori algorithm we've used Minimum Support, Confidence and Lift in order to determine the association between the items. We have then plot the associated items when we picked the item from the list to get the idea of what people bought together frequently.

Check App [here](https://share.streamlit.io/yogeshkumar22/market_basket_analysis_streamlit_app/main/mba_app.py)

Download dataset [here](https://github.com/yogeshkumar22/market_basket_analysis_streamlit_app/blob/main/Market_Basket_Optimisation.csv)

## A glimpse of the web app:

![GIF](mba_streamlitt.gif)
